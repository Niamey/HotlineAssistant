﻿using System;
using System.Net.Http;
using ContactManager.FunctionalTests.Api;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace ContactManager.FunctionalTests.Fixtures
{
    public abstract class ApiControllerTestFixture : IClassFixture<ServiceFactory<TestStartup>>, IDisposable
    {
        protected readonly HttpClient Client;

        private readonly IServiceScope _scope;

        protected ApiControllerTestFixture(ServiceFactory<TestStartup> factory)
        {
            Client = factory.CreateClient();
            _scope = factory.CreateScope();
        }
        
        public void Dispose()
        {
            _scope.Dispose();
        }
    }
}