﻿using System.Net;
using System.Threading.Tasks;
using ContactManager.FunctionalTests.Fixtures;
using Xunit;

namespace ContactManager.FunctionalTests.Api
{
    public class ClientBalanceControllerTest : ApiControllerTestFixture
    {
        private const string BaseUrl = "api/client/balances";
        private const int ClientId = 100298;

        public ClientBalanceControllerTest(ServiceFactory<TestStartup> factory) : base(factory)
        {
        }
        
        //[Fact]
        public async Task Get()
        {
            //Act
            var url = $"{BaseUrl}/{ClientId}";
            var response = await Client.GetAsync(url);

            //Assert
            response.EnsureSuccessStatusCode();
        }

        [Fact]
        public async Task Get_WhenIsNotFound_ReturnsNotFound()
        {
            //Act
            var url = $"{BaseUrl}/{ClientId}";
            var response = await Client.GetAsync(url);

            //Assert
            Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        }
    }
}