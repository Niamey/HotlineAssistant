﻿using System.Net;
using System.Threading.Tasks;
using ContactManager.FunctionalTests.Fixtures;
using Solar.Models.Models.Params;
using Xunit;

namespace ContactManager.FunctionalTests.Api
{
	public class ClientControllerTest : ApiControllerTestFixture
	{
		private const string BaseUrl = "api/client";

		public ClientControllerTest(ServiceFactory<TestStartup> factory) : base(factory)
		{
		}

		[Fact]
		public async Task Get_WhenIsNotFound_ReturnsNotFound()
		{
			//Act
			var url = $"{BaseUrl}";
			var response = await Client.GetAsync(url);

			//Assert
			Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
		}
    }
}